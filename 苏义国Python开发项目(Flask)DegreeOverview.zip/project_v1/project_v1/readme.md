
## Resource

* [Flask1.0+](https://flask.palletsprojects.com/en/1.1.x/)
* [SQLAlchemy](https://www.sqlalchemy.org/)

* [flask_login]( https://www.cnblogs.com/qjj19931230/p/12405555.html)


## library

```py
pip install Flask PyMySQL SQLAlchemy Flask-SQLAlchemy
```

1. secure.py  update your own db

2. app -> __init__.py   update blueprint

