import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * This is a Command Line Interface class
 */

/**
 * @author Stefan_SU
 *
 */
public class CLI {
	// Declare a private static variable input and use standard input
	private static Scanner input = new Scanner(System.in);

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1 = readLine("Type some text: ");// Test readLine() method with "Type some text: "
		System.out.println("Text read is: " + str1);// output the result of readLine()
		int i = readPosInt("Type an integer: ");// get the integer through readPosInt() method with "Type an integer: "
		System.out.println("Integer read is: " + i);// output the result of readPosInt()
		String str2 = readLine("Type some text again: ");// Test readLine() method with "Type some text again: "
		System.out.println("Text read is: " + str2);// output the result of readLine()
	}

	// Create a private static String method called readLine()
	private static String readLine(String inputStr) {
		System.out.print(inputStr);// print the initial sentence
		String inputMessage = input.nextLine();// read the String input
		return inputMessage;// return inputMessage
	}

	// Create a private static integer method called readPosInt()
	private static int readPosInt(String inputInt) {
		while (true) {
			System.out.print(inputInt);// output the initial message
			int inputInteger = 0;// initialize inputInteger as 0
			try {
				inputInteger = input.nextInt();// get the integer as input
			} catch (InputMismatchException e) {// determine it is an exception or not
				// TODO: handle exception
				System.out.println("You must type a integer!");// show the wrong message
				input.nextLine();// if wrong, get the next input
				continue;// end this time's while loop and start next loop
			}
			input.nextLine();// if wrong, get the next input
			if (inputInteger < 0) {// Determine the inputInteger is larger than or equal to 0
				System.out.println("Positive integers only!");// show the wrong message
			} else {
				return inputInteger;// return the inputInteger
			}
		}
	}

}
