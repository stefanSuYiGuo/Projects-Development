/**
 * This is ViewHistory class that extends View<ControllerHistory>
 */

/**
 * @author Stefan_SU
 *
 */
public class ControllerHistory extends Controller {

	public ControllerHistory(FinanceOffice m) {// Create a constructor
		super(m);// Initialize m
		// TODO Auto-generated constructor stub
	}

}
