/**
 * This is GUI class to run that code on the event dispatch thread.
 */

/**
 * @author Stefan_SU
 *
 */
public class GUI {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		javax.swing.SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {// Override run() method
				// TODO Auto-generated method stub
				// Create a new FinanceOffice object
				FinanceOffice finaceOffice = new FinanceOffice("UIC FO");
				
//				System.out.println("***********TESTING*************");
//				Student student = new Student("Stefan", 1000);
//				try {
//					Employee employee = new Employee("Constance", 50000);
//					finaceOffice.addPayer(employee);
//				} catch (NegativeSalaryException e) {
//					// TODO Auto-generated catch block
//					System.out.println(e.getMessage());
//				}
//				try {
//					FacultyMember facultyMember = new FacultyMember("Eli", 20000);
//					finaceOffice.addPayer(facultyMember);
//				} catch (NegativeSalaryException e) {
//					// TODO Auto-generated catch block
//					System.out.println(e.getMessage());
//				}
//				finaceOffice.addPayer(student);
//				System.out.println("*********END OF TESTING*********");
				
				// Create a new ControllerSimple object
				ControllerSimple controllerSimple = new ControllerSimple(finaceOffice);
				// Create a new ViewSimple object
				ViewSimple viewSimple = new ViewSimple(finaceOffice, controllerSimple);
			}
		});
	}

}
