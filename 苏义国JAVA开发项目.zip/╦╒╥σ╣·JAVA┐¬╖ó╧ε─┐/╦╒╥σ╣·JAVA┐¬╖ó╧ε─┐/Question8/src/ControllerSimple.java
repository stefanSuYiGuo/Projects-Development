/**
 * This is ControllerSimple class to control model
 */

/**
 * @author Stefan_SU
 *
 */
public class ControllerSimple {
	private FinanceOffice m;// Declare a FinanceOffice variable called m

	public ControllerSimple(FinanceOffice m) {// Create a constructor
		this.m = m;// assign m
	}
}
