/**
 * This is a main Test class 
 */

/**
 * @author Stefan_SU
 *
 */
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person.testPerson();// Call a method called testPerson()
		Student.testStudent();// Call a method called testStudent()
		Employee.testEmployee();// Call a method called testEmployee()
	}

}
