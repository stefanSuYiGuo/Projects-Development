import javax.swing.JFrame;

/**
 * This is a super View class of all views
 */

/**
 * @author Stefan_SU
 *
 */
public abstract class View<T extends Controller> extends JFrame implements ModelListener {
	protected FinanceOffice m;
	protected T c;
	
	public View(FinanceOffice m, T c) {
		this.m = m;// Assign m
		this.c = c;// Assign c
		// call addListener() and the view registers itself with the model
		m.addListener(this);
		// kill the program while closing the window
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public abstract void update();
}
