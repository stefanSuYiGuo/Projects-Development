/**
 * This is an interface called GUI
 */

/**
 * @author Stefan_SU
 *
 */
public interface ModelListener {

	public void update();// Create update() method
}
