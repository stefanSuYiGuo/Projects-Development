/**
 * This is a Controller class
 */

/**
 * @author Stefan_SU
 *
 */
public class Controller {
	protected FinanceOffice m;// the protected variable m type FinanceOffice

	// Create a constructor
	public Controller(FinanceOffice m) {
		this.m = m;// Assign m
	}
}
